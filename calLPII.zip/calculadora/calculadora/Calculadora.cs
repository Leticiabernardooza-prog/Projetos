﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace calculadora
{
    class Calculadora
    {
        static EntradaSaida entradaSaida = new EntradaSaida();

        static void Main(string[] args)
        {

            bool controleRepeticao = true;

            Console.WriteLine("*****************CALCULADORA*****************");

            while(controleRepeticao)
            {
                entradaSaida.LimparSaida();
                entradaSaida.LerTeclado();
                entradaSaida.Imprimir();
                
                controleRepeticao = entradaSaida.Parar();
            }
        }
    }
}
