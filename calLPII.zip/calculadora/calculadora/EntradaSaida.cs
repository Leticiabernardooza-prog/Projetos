﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace calculadora
{
    class EntradaSaida
    {
        Soma soma = new Soma();
        Subtracao subtracao = new Subtracao();
        Multiplicacao multiplicacao = new Multiplicacao();
        Divisao divisao = new Divisao();


        double valor1 = 0, valor2 = 0;
        string opString = "";
        char opChar;
        string[] op = { "+", "-", "*", "/" };
        string opFinal = "";


        public void Imprimir()
        { 
            switch (opFinal)
            {
                case "+":
                    Console.WriteLine("A SOMA É: {0}.", soma.calcular(valor1, valor2));
                    break;
                case "-":
                    Console.WriteLine("A SUBTRAÇÃO É: {0}.", subtracao.calcular(valor1, valor2));
                    break;
                case "*":
                    Console.WriteLine("A MULTIPLICAÇÃO É: {0}.", multiplicacao.calcular(valor1, valor2));
                    break;
                case "/":
                    Console.WriteLine("A DIVISÃO É: {0}.", divisao.calcular(valor1, valor2));
                    break;
            }
        }
        public void ImprimirLn(String texto)
        {
            // imprimir quebra de linha
            Console.WriteLine(""); 
        }
        public void LerTeclado()
        {
            // Ler o valor
            Console.Write("Insira o primeiro valor: ");
            valor1 = Convert.ToDouble(Console.ReadLine());
            Console.Write("Insira o tipo de operação: ");
            opString = Console.ReadLine();
            Console.Write("Insira o segundo valor: ");
            valor2 = Convert.ToDouble(Console.ReadLine());
            if (opString.Length == 1)
            {
                opChar = Convert.ToChar(opString);
                LerOpcao(opChar);
            }
        }
        public void LerOpcao(char texto)
        {
            // Ler opção de caracter +, -, *, / 
            switch (opChar)
            {
                case '+':
                    opFinal = "+";
                    break;
                case '-':
                    opFinal = "-";
                    break;
                case '*':
                    opFinal = "*";
                    break;
                case '/':
                    opFinal = "/";
                    break;
                default:
                    Console.WriteLine("Operação Inválida...");
                    break; 
            }
        }
        public void LimparSaida()
        {
            // vai apagar oque foi escrito anteriormente
            Console.Clear();
           
        }
        //loop que retorna enquanto o 's' for acionado
        public bool Parar()
        {
            string ver;
            Console.WriteLine("Deseja continuar na calculadora?(S/N):");
            ver = Console.ReadLine();
            if (ver.ToLower() == "s")
            {
                return true;
            }
            return false;
        }
    }
}
