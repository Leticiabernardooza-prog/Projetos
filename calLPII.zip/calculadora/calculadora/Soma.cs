﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace calculadora
{
    class Soma
    {
        public String calcular(double valor1, double valor2)
        {
            double dr = valor1 + valor2;
            return dr.ToString();
        }

    }
}
